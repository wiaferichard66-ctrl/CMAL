import { useState, useEffect, useMemo, useCallback } from "react";
import {
  ResponsiveContainer, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from "recharts";
import {
  LayoutDashboard, Building2, Tags, Receipt as ReceiptIcon, Landmark,
  Wallet, FileBarChart, ShieldCheck, Plus, Trash2, X, Search, ChevronRight,
  ChevronLeft, Download, PlayCircle, AlertTriangle,
} from "lucide-react";

// ─────────────────────────────────────────────────────────────
// Constants & helpers
// ─────────────────────────────────────────────────────────────

const STORAGE_KEY = "cma-registry-data-v1";

const CURRENCY = "USD";
const fmt = (n) =>
  `${CURRENCY} ${Number(n || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const fmtCompact = (n) =>
  `${CURRENCY} ${Number(n || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

const periodKey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
const periodLabel = (p) => {
  const [y, m] = p.split("-");
  return new Date(Number(y), Number(m) - 1, 1).toLocaleDateString(undefined, { month: "short", year: "numeric" });
};
const addMonths = (date, months) => {
  const d = new Date(date);
  d.setMonth(d.getMonth() + months);
  return d;
};
const daysBetween = (a, b) => Math.round((new Date(b) - new Date(a)) / 86400000);

const ROLES = [
  { id: "ADMIN", label: "Administrator" },
  { id: "FINANCE", label: "Finance Officer" },
  { id: "REGISTRY", label: "Registry Officer" },
  { id: "AUDITOR", label: "Auditor (Read Only)" },
  { id: "EXECUTIVE", label: "Executive (Dashboards Only)" },
];

const NAV_ITEMS = [
  { id: "executive", label: "Executive Dashboard", icon: LayoutDashboard, roles: ["ADMIN", "FINANCE", "REGISTRY", "AUDITOR", "EXECUTIVE"] },
  { id: "collections", label: "Collections", icon: Wallet, roles: ["ADMIN", "FINANCE", "REGISTRY", "AUDITOR", "EXECUTIVE"] },
  { id: "registry", label: "Registry Revenue", icon: Landmark, roles: ["ADMIN", "FINANCE", "REGISTRY", "AUDITOR", "EXECUTIVE"] },
  { id: "receipts", label: "Receipts", icon: ReceiptIcon, roles: ["ADMIN", "FINANCE", "AUDITOR"] },
  { id: "entities", label: "Entities", icon: Building2, roles: ["ADMIN", "FINANCE", "REGISTRY"] },
  { id: "feeTypes", label: "Fee Types", icon: Tags, roles: ["ADMIN"] },
  { id: "reports", label: "Reports", icon: FileBarChart, roles: ["ADMIN", "FINANCE", "AUDITOR"] },
  { id: "audit", label: "Audit Trail", icon: ShieldCheck, roles: ["ADMIN", "AUDITOR"] },
];

const CHART_COLORS = ["#4F46E5", "#059669", "#D97706", "#DC2626", "#0891B2", "#7C3AED", "#DB2777"];

const DEFAULT_FEE_TYPES = [
  { name: "Registration Fee", code: "REG", category: "IMMEDIATE", defaultMonths: null },
  { name: "Registry Fee", code: "REGY", category: "DEFERRED", defaultMonths: 12 },
  { name: "Transfer Fee", code: "TRF", category: "IMMEDIATE", defaultMonths: null },
  { name: "Verification Fee", code: "VER", category: "IMMEDIATE", defaultMonths: null },
  { name: "Project Approval Fee", code: "PAF", category: "IMMEDIATE", defaultMonths: null },
  { name: "Emissions Revenue", code: "EMR", category: "IMMEDIATE", defaultMonths: null },
  { name: "Government Revenue", code: "GOV", category: "IMMEDIATE", defaultMonths: null },
  { name: "Grant Revenue", code: "GRT", category: "DEFERRED", defaultMonths: 24 },
].map((f) => ({ ...f, id: uid(), isActive: true }));

function emptyData() {
  return {
    entities: [],
    feeTypes: DEFAULT_FEE_TYPES,
    receipts: [],
    schedules: [],
    recognitions: [],
    journalEntries: [],
    auditLog: [],
    receiptSeq: {},
  };
}

// ─────────────────────────────────────────────────────────────
// Small shared UI primitives
// ─────────────────────────────────────────────────────────────

function Card({ children, className = "" }) {
  return <div className={`rounded-xl border border-slate-200 bg-white shadow-sm ${className}`}>{children}</div>;
}

function StatCard({ label, value, sub, accent = "slate" }) {
  const accentMap = {
    slate: "text-slate-900",
    indigo: "text-indigo-600",
    emerald: "text-emerald-600",
    amber: "text-amber-600",
  };
  return (
    <Card className="p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</p>
      <p className={`mt-1.5 font-mono text-xl font-semibold ${accentMap[accent]}`}>{value}</p>
      {sub && <p className="mt-1 text-xs text-slate-400">{sub}</p>}
    </Card>
  );
}

function SectionHeader({ title, description, action }) {
  return (
    <div className="mb-5 flex items-start justify-between gap-4">
      <div>
        <h2 className="text-lg font-semibold text-slate-900">{title}</h2>
        {description && <p className="mt-0.5 text-sm text-slate-500">{description}</p>}
      </div>
      {action}
    </div>
  );
}

function Btn({ children, onClick, variant = "primary", size = "md", disabled, type = "button", className = "" }) {
  const base = "inline-flex items-center gap-1.5 rounded-md font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed";
  const sizes = { md: "px-3.5 py-2 text-sm", sm: "px-2.5 py-1.5 text-xs" };
  const variants = {
    primary: "bg-indigo-600 text-white hover:bg-indigo-700",
    secondary: "bg-white border border-slate-300 text-slate-700 hover:bg-slate-50",
    ghost: "text-slate-500 hover:bg-slate-100",
    danger: "text-red-600 hover:bg-red-50",
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled} className={`${base} ${sizes[size]} ${variants[variant]} ${className}`}>
      {children}
    </button>
  );
}

function Field({ label, children, hint }) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-slate-600">{label}</span>
      <div className="mt-1">{children}</div>
      {hint && <span className="mt-1 block text-xs text-slate-400">{hint}</span>}
    </label>
  );
}

const inputCls = "w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-800 placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500";

function DataTable({ columns, data, keyField, emptyMessage = "No records yet." }) {
  return (
    <div className="overflow-x-auto rounded-lg border border-slate-200">
      <table className="min-w-full divide-y divide-slate-200 text-sm">
        <thead className="bg-slate-50">
          <tr>
            {columns.map((c) => (
              <th key={c.header} className="whitespace-nowrap px-4 py-2.5 text-left text-xs font-medium uppercase tracking-wide text-slate-500">
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 bg-white">
          {data.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="px-4 py-10 text-center text-sm text-slate-400">{emptyMessage}</td>
            </tr>
          ) : (
            data.map((row) => (
              <tr key={row[keyField]} className="hover:bg-slate-50">
                {columns.map((c) => (
                  <td key={c.header} className="whitespace-nowrap px-4 py-2.5 text-slate-700">{c.render(row)}</td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

function Badge({ children, tone = "slate" }) {
  const tones = {
    slate: "bg-slate-100 text-slate-600",
    emerald: "bg-emerald-50 text-emerald-700",
    amber: "bg-amber-50 text-amber-700",
    indigo: "bg-indigo-50 text-indigo-700",
    red: "bg-red-50 text-red-700",
  };
  return <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${tones[tone]}`}>{children}</span>;
}

function Modal({ open, onClose, title, children, wide }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
      <div className={`max-h-[90vh] w-full ${wide ? "max-w-2xl" : "max-w-md"} overflow-y-auto rounded-xl bg-white shadow-xl`}>
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
          <h3 className="text-sm font-semibold text-slate-900">{title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

// CSV export helper — client-side, no backend needed
function downloadCsv(filename, rows, columns) {
  const header = columns.map((c) => `"${c.header}"`).join(",");
  const lines = rows.map((r) => columns.map((c) => `"${String(c.value(r) ?? "").replace(/"/g, '""')}"`).join(","));
  const csv = [header, ...lines].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ─────────────────────────────────────────────────────────────
// Main App
// ─────────────────────────────────────────────────────────────

export default function CMARegistryApp() {
  const [data, setData] = useState(null);
  const [loaded, setLoaded] = useState(false);
  const [tab, setTab] = useState("executive");
  const [role, setRole] = useState("ADMIN");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [toast, setToast] = useState(null);

  // Load from persistent storage on mount (browser localStorage)
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      setData(raw ? JSON.parse(raw) : emptyData());
    } catch {
      setData(emptyData());
    } finally {
      setLoaded(true);
    }
  }, []);

  // Persist on every change
  useEffect(() => {
    if (!loaded || !data) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      // localStorage can throw if full or disabled (e.g. private browsing) — fail silently
    }
  }, [data, loaded]);

  const showToast = useCallback((msg, tone = "emerald") => {
    setToast({ msg, tone });
    setTimeout(() => setToast(null), 3200);
  }, []);

  const logAudit = useCallback((action, entityName, recordId, extra = "") => {
    setData((d) => ({
      ...d,
      auditLog: [
        { id: uid(), user: ROLES.find((r) => r.id === role)?.label ?? role, action, entityName, recordId, extra, timestamp: new Date().toISOString() },
        ...d.auditLog,
      ].slice(0, 500),
    }));
  }, [role]);

  // ── Mutations ──────────────────────────────────────────────

  const addEntity = useCallback((entity) => {
    const record = { ...entity, id: uid(), createdAt: new Date().toISOString() };
    setData((d) => ({ ...d, entities: [record, ...d.entities] }));
    logAudit("CREATE", "Entity", record.id, record.name);
    return record;
  }, [logAudit]);

  const addFeeType = useCallback((ft) => {
    const record = { ...ft, id: uid(), isActive: true };
    setData((d) => ({ ...d, feeTypes: [...d.feeTypes, record] }));
    logAudit("CREATE", "FeeType", record.id, record.name);
  }, [logAudit]);

  const toggleFeeType = useCallback((id) => {
    setData((d) => ({
      ...d,
      feeTypes: d.feeTypes.map((f) => (f.id === id ? { ...f, isActive: !f.isActive } : f)),
    }));
    logAudit("UPDATE", "FeeType", id, "toggled active status");
  }, [logAudit]);

  const createReceipt = useCallback((input) => {
    let createdReceiptNumber = "";
    setData((d) => {
      const year = new Date().getFullYear();
      const seq = (d.receiptSeq[year] || 0) + 1;
      const receiptNumber = `CMA-${year}-${String(seq).padStart(3, "0")}`;
      createdReceiptNumber = receiptNumber;
      const totalAmount = input.lineItems.reduce((s, li) => s + Number(li.amount), 0);
      const receiptId = uid();
      const paymentDate = new Date().toISOString();
      const period = periodKey(new Date());

      const receipt = {
        id: receiptId,
        receiptNumber,
        entityId: input.entityId,
        paymentDate,
        paymentMethod: input.paymentMethod,
        collectedBy: input.collectedBy || "Front Desk",
        notes: input.notes || "",
        totalAmount,
        lineItems: input.lineItems.map((li) => ({ ...li, id: uid() })),
      };

      const newSchedules = [];
      const newRecognitions = [];
      const newJournalEntries = [];

      for (const li of receipt.lineItems) {
        const feeType = d.feeTypes.find((f) => f.id === li.feeTypeId);
        if (!feeType) continue;

        if (feeType.category === "IMMEDIATE") {
          const recId = uid();
          newRecognitions.push({
            id: recId, type: "IMMEDIATE", receiptId, scheduleId: null,
            entityId: input.entityId, feeTypeId: feeType.id, amount: Number(li.amount),
            period, date: paymentDate,
          });
          newJournalEntries.push({
            id: uid(), recognitionId: recId, date: paymentDate, period,
            debitAccount: "Cash / Bank", creditAccount: "Registry Revenue",
            amount: Number(li.amount),
            description: `Immediate recognition — ${feeType.name} — ${receiptNumber}`,
          });
        } else {
          const months = Number(li.months) || feeType.defaultMonths || 12;
          const monthlyAmount = Number(li.amount) / months;
          const startDate = new Date(paymentDate);
          newSchedules.push({
            id: uid(), receiptId, entityId: input.entityId, feeTypeId: feeType.id,
            totalAmount: Number(li.amount), monthlyAmount, recognizedAmount: 0,
            remainingBalance: Number(li.amount),
            startDate: startDate.toISOString(), endDate: addMonths(startDate, months).toISOString(),
            status: "ACTIVE", months,
          });
        }
      }

      return {
        ...d,
        receiptSeq: { ...d.receiptSeq, [year]: seq },
        receipts: [receipt, ...d.receipts],
        schedules: [...newSchedules, ...d.schedules],
        recognitions: [...newRecognitions, ...d.recognitions],
        journalEntries: [...newJournalEntries, ...d.journalEntries],
      };
    });
    logAudit("CREATE", "Receipt", createdReceiptNumber);
    return createdReceiptNumber;
  }, [logAudit]);

  const runMonthlyRecognition = useCallback((periodOverride) => {
    let summary = { period: "", processed: 0, amount: 0, skipped: 0 };
    setData((d) => {
      const period = periodOverride || periodKey(new Date());
      summary.period = period;
      const newRecognitions = [];
      const newJournalEntries = [];
      const updatedSchedules = d.schedules.map((sch) => {
        if (sch.status !== "ACTIVE") return sch;
        const alreadyRun = d.recognitions.some((r) => r.scheduleId === sch.id && r.period === period);
        if (alreadyRun) {
          summary.skipped += 1;
          return sch;
        }
        const amount = Math.min(sch.monthlyAmount, sch.remainingBalance);
        if (amount <= 0) return sch;

        const recId = uid();
        newRecognitions.push({
          id: recId, type: "DEFERRED", receiptId: sch.receiptId, scheduleId: sch.id,
          entityId: sch.entityId, feeTypeId: sch.feeTypeId, amount, period,
          date: new Date().toISOString(),
        });
        newJournalEntries.push({
          id: uid(), recognitionId: recId, date: new Date().toISOString(), period,
          debitAccount: "Deferred Income", creditAccount: "Registry Revenue", amount,
          description: `Monthly recognition — schedule ${sch.id.slice(0, 6)} — ${period}`,
        });

        summary.processed += 1;
        summary.amount += amount;

        const newRecognized = sch.recognizedAmount + amount;
        const newRemaining = sch.remainingBalance - amount;
        return {
          ...sch,
          recognizedAmount: newRecognized,
          remainingBalance: Math.max(0, newRemaining),
          status: newRemaining <= 0.005 ? "COMPLETED" : "ACTIVE",
        };
      });

      return {
        ...d,
        schedules: updatedSchedules,
        recognitions: [...newRecognitions, ...d.recognitions],
        journalEntries: [...newJournalEntries, ...d.journalEntries],
      };
    });
    logAudit("RUN", "MonthlyRecognition", summary.period);
    return summary;
  }, [logAudit]);

  // ── Derived data for dashboards ─────────────────────────────

  const derived = useMemo(() => {
    if (!data) return null;
    const feeTypeById = Object.fromEntries(data.feeTypes.map((f) => [f.id, f]));
    const entityById = Object.fromEntries(data.entities.map((e) => [e.id, e]));

    const totalCollections = data.receipts.reduce((s, r) => s + r.totalAmount, 0);
    const totalRevenueRecognised = data.recognitions.reduce((s, r) => s + r.amount, 0);
    const totalDeferred = data.schedules.filter((s) => s.status === "ACTIVE").reduce((s, sc) => s + sc.remainingBalance, 0);

    const now = new Date();
    const currentMonthKey = periodKey(now);
    const monthlyCollections = data.receipts.filter((r) => r.paymentDate.startsWith(currentMonthKey)).reduce((s, r) => s + r.totalAmount, 0);

    // Revenue by month (last 6 months, recognitions)
    const monthBuckets = [];
    for (let i = 5; i >= 0; i--) {
      const d2 = addMonths(now, -i);
      monthBuckets.push(periodKey(d2));
    }
    const revenueByMonth = monthBuckets.map((p) => ({
      period: periodLabel(p),
      revenue: data.recognitions.filter((r) => r.period === p).reduce((s, r) => s + r.amount, 0),
      collections: data.receipts.filter((r) => r.paymentDate.startsWith(p)).reduce((s, r) => s + r.totalAmount, 0),
    }));

    // Revenue by fee type
    const byFeeTypeMap = {};
    for (const r of data.recognitions) {
      const name = feeTypeById[r.feeTypeId]?.name ?? "Unknown";
      byFeeTypeMap[name] = (byFeeTypeMap[name] || 0) + r.amount;
    }
    const revenueByFeeType = Object.entries(byFeeTypeMap).map(([name, value]) => ({ name, value }));

    // Revenue by entity (top 8)
    const byEntityMap = {};
    for (const r of data.recognitions) {
      const name = entityById[r.entityId]?.name ?? "Unknown";
      byEntityMap[name] = (byEntityMap[name] || 0) + r.amount;
    }
    const revenueByEntity = Object.entries(byEntityMap)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);

    // Collections by payment method
    const byMethodMap = {};
    for (const r of data.receipts) {
      byMethodMap[r.paymentMethod] = (byMethodMap[r.paymentMethod] || 0) + r.totalAmount;
    }
    const collectionsByMethod = Object.entries(byMethodMap).map(([name, value]) => ({ name, value }));

    // Collections by officer
    const byOfficerMap = {};
    for (const r of data.receipts) {
      byOfficerMap[r.collectedBy] = (byOfficerMap[r.collectedBy] || 0) + r.totalAmount;
    }
    const collectionsByOfficer = Object.entries(byOfficerMap).map(([name, value]) => ({ name, value }));

    // Daily collections (last 14 days)
    const dayBuckets = [];
    for (let i = 13; i >= 0; i--) {
      const d2 = new Date(now); d2.setDate(d2.getDate() - i);
      dayBuckets.push(d2.toISOString().slice(0, 10));
    }
    const dailyCollections = dayBuckets.map((day) => ({
      day: new Date(day).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
      amount: data.receipts.filter((r) => r.paymentDate.startsWith(day)).reduce((s, r) => s + r.totalAmount, 0),
    }));

    const contractsExpiringSoon = data.schedules
      .filter((s) => s.status === "ACTIVE" && daysBetween(now, s.endDate) <= 60)
      .sort((a, b) => new Date(a.endDate) - new Date(b.endDate));

    return {
      feeTypeById, entityById, totalCollections, totalRevenueRecognised, totalDeferred,
      monthlyCollections, revenueByMonth, revenueByFeeType, revenueByEntity,
      collectionsByMethod, collectionsByOfficer, dailyCollections, contractsExpiringSoon,
      currentMonthKey,
    };
  }, [data]);

  if (!loaded || !data || !derived) {
    return <div className="flex h-screen items-center justify-center bg-slate-50 text-slate-400">Loading registry data…</div>;
  }

  const visibleNav = NAV_ITEMS.filter((n) => n.roles.includes(role));
  const activeNav = visibleNav.find((n) => n.id === tab) ? tab : visibleNav[0]?.id;

  return (
    <div className="flex h-screen w-full overflow-hidden bg-slate-50 font-sans text-slate-800">
      {/* Sidebar */}
      <aside className={`flex flex-col bg-slate-900 text-slate-300 transition-all ${sidebarOpen ? "w-60" : "w-16"}`}>
        <div className="flex items-center justify-between border-b border-slate-800 px-4 py-4">
          {sidebarOpen && (
            <div>
              <p className="text-sm font-semibold text-white tracking-tight">CMA Registry</p>
              <p className="text-[11px] text-slate-500">Revenue Management</p>
            </div>
          )}
          <button onClick={() => setSidebarOpen((v) => !v)} className="text-slate-500 hover:text-white">
            {sidebarOpen ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
          </button>
        </div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto px-2 py-3">
          {visibleNav.map((item) => {
            const Icon = item.icon;
            const isActive = activeNav === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setTab(item.id)}
                className={`flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors ${
                  isActive ? "bg-indigo-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"
                }`}
                title={item.label}
              >
                <Icon size={16} className="shrink-0" />
                {sidebarOpen && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>
        <div className="border-t border-slate-800 p-3">
          {sidebarOpen && <p className="mb-1.5 text-[11px] uppercase tracking-wide text-slate-500">Viewing as</p>}
          <select
            value={role}
            onChange={(e) => setRole(e.target.value)}
            className="w-full rounded-md border border-slate-700 bg-slate-800 px-2 py-1.5 text-xs text-slate-200"
          >
            {ROLES.map((r) => <option key={r.id} value={r.id}>{sidebarOpen ? r.label : r.id}</option>)}
          </select>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-6xl p-6">
          {activeNav === "executive" && <ExecutiveDashboard derived={derived} data={data} />}
          {activeNav === "collections" && <CollectionsDashboard derived={derived} />}
          {activeNav === "registry" && (
            <RegistryDashboard derived={derived} data={data} runMonthlyRecognition={runMonthlyRecognition} showToast={showToast} role={role} />
          )}
          {activeNav === "receipts" && (
            <ReceiptsPage data={data} derived={derived} createReceipt={createReceipt} addEntity={addEntity} showToast={showToast} />
          )}
          {activeNav === "entities" && <EntitiesPage data={data} addEntity={addEntity} derived={derived} showToast={showToast} />}
          {activeNav === "feeTypes" && <FeeTypesPage data={data} addFeeType={addFeeType} toggleFeeType={toggleFeeType} showToast={showToast} />}
          {activeNav === "reports" && <ReportsPage data={data} derived={derived} />}
          {activeNav === "audit" && <AuditPage data={data} />}
        </div>
      </main>

      {toast && (
        <div className={`fixed bottom-5 right-5 z-50 rounded-lg px-4 py-3 text-sm text-white shadow-lg ${toast.tone === "emerald" ? "bg-emerald-600" : "bg-red-600"}`}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Executive Dashboard
// ─────────────────────────────────────────────────────────────

function ExecutiveDashboard({ derived, data }) {
  return (
    <div>
      <SectionHeader title="Executive Dashboard" description="Registry-wide collection and revenue performance." />
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label="Total Collections" value={fmtCompact(derived.totalCollections)} accent="indigo" />
        <StatCard label="Monthly Collections" value={fmtCompact(derived.monthlyCollections)} sub={periodLabel(derived.currentMonthKey)} accent="indigo" />
        <StatCard label="Revenue Recognised" value={fmtCompact(derived.totalRevenueRecognised)} accent="emerald" />
        <StatCard label="Deferred Income" value={fmtCompact(derived.totalDeferred)} accent="amber" />
        <StatCard label="Total Entities" value={data.entities.length} />
        <StatCard label="Total Receipts" value={data.receipts.length} />
        <StatCard label="Active Prepaid Contracts" value={data.schedules.filter((s) => s.status === "ACTIVE").length} />
        <StatCard label="Outstanding Balance" value={fmtCompact(derived.totalDeferred)} sub="Yet to be recognised" accent="amber" />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card className="p-4">
          <p className="mb-3 text-sm font-medium text-slate-700">Revenue vs. Collections by Month</p>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={derived.revenueByMonth}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="period" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} tickFormatter={fmtCompact} width={80} />
              <Tooltip formatter={(v) => fmt(v)} />
              <Legend />
              <Bar dataKey="collections" name="Collections" fill="#94A3B8" radius={[3, 3, 0, 0]} />
              <Bar dataKey="revenue" name="Revenue Recognised" fill="#4F46E5" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-4">
          <p className="mb-3 text-sm font-medium text-slate-700">Revenue by Fee Type</p>
          {derived.revenueByFeeType.length === 0 ? (
            <p className="py-16 text-center text-sm text-slate-400">No revenue recognised yet.</p>
          ) : (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={derived.revenueByFeeType} dataKey="value" nameKey="name" outerRadius={85} label={(e) => e.name}>
                  {derived.revenueByFeeType.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v) => fmt(v)} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </Card>
      </div>

      <Card className="mt-4 p-4">
        <p className="mb-3 text-sm font-medium text-slate-700">Revenue by Entity (Top 8)</p>
        {derived.revenueByEntity.length === 0 ? (
          <p className="py-10 text-center text-sm text-slate-400">No revenue recognised yet.</p>
        ) : (
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={derived.revenueByEntity} layout="vertical" margin={{ left: 24 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis type="number" tick={{ fontSize: 12 }} tickFormatter={fmtCompact} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 12 }} width={140} />
              <Tooltip formatter={(v) => fmt(v)} />
              <Bar dataKey="value" fill="#059669" radius={[0, 3, 3, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Collections Dashboard
// ─────────────────────────────────────────────────────────────

function CollectionsDashboard({ derived }) {
  return (
    <div>
      <SectionHeader title="Collection Dashboard" description="Cash inflows by day, method, and officer." />
      <Card className="p-4">
        <p className="mb-3 text-sm font-medium text-slate-700">Daily Collections (last 14 days)</p>
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={derived.dailyCollections}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
            <XAxis dataKey="day" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 12 }} tickFormatter={fmtCompact} width={80} />
            <Tooltip formatter={(v) => fmt(v)} />
            <Line type="monotone" dataKey="amount" stroke="#4F46E5" strokeWidth={2} dot={{ r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card className="p-4">
          <p className="mb-3 text-sm font-medium text-slate-700">Cash by Payment Method</p>
          {derived.collectionsByMethod.length === 0 ? (
            <p className="py-14 text-center text-sm text-slate-400">No collections recorded yet.</p>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={derived.collectionsByMethod} dataKey="value" nameKey="name" outerRadius={80} label={(e) => e.name}>
                  {derived.collectionsByMethod.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v) => fmt(v)} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </Card>
        <Card className="p-4">
          <p className="mb-3 text-sm font-medium text-slate-700">Collections by Officer</p>
          {derived.collectionsByOfficer.length === 0 ? (
            <p className="py-14 text-center text-sm text-slate-400">No collections recorded yet.</p>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={derived.collectionsByOfficer}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={fmtCompact} width={80} />
                <Tooltip formatter={(v) => fmt(v)} />
                <Bar dataKey="value" fill="#0891B2" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Card>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Registry Revenue Dashboard (deferred income + recognition)
// ─────────────────────────────────────────────────────────────

function RegistryDashboard({ derived, data, runMonthlyRecognition, showToast, role }) {
  const canRun = role === "ADMIN" || role === "FINANCE";
  const activeSchedules = data.schedules.filter((s) => s.status === "ACTIVE");

  function handleRun() {
    const result = runMonthlyRecognition();
    if (result.processed === 0 && result.skipped === 0) {
      showToast("No active prepaid contracts to recognise.", "red");
    } else if (result.processed === 0) {
      showToast(`${periodLabel(result.period)} already recognised for all active contracts.`, "red");
    } else {
      showToast(`Recognised ${fmt(result.amount)} across ${result.processed} contract(s) for ${periodLabel(result.period)}.`);
    }
  }

  return (
    <div>
      <SectionHeader
        title="Registry Revenue"
        description="Deferred income schedules and monthly revenue recognition."
        action={canRun && (
          <Btn onClick={handleRun}><PlayCircle size={15} /> Run Recognition for {periodLabel(periodKey(new Date()))}</Btn>
        )}
      />

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label="Registry Revenue (Total)" value={fmtCompact(derived.totalRevenueRecognised)} accent="emerald" />
        <StatCard label="Deferred Revenue" value={fmtCompact(derived.totalDeferred)} accent="amber" />
        <StatCard label="Active Prepaid Contracts" value={activeSchedules.length} />
        <StatCard label="Expiring Within 60 Days" value={derived.contractsExpiringSoon.length} accent={derived.contractsExpiringSoon.length ? "amber" : "slate"} />
      </div>

      {derived.contractsExpiringSoon.length > 0 && (
        <div className="mt-4 flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" />
          <span>{derived.contractsExpiringSoon.length} prepaid contract(s) fully recognise within 60 days — see the schedule below.</span>
        </div>
      )}

      <Card className="mt-6 p-4">
        <p className="mb-3 text-sm font-medium text-slate-700">Recognition Schedule — Prepaid Contracts</p>
        <div className="space-y-3">
          {data.schedules.length === 0 && <p className="py-6 text-center text-sm text-slate-400">No deferred-income contracts recorded yet.</p>}
          {data.schedules.map((s) => {
            const feeType = derived.feeTypeById[s.feeTypeId];
            const entity = derived.entityById[s.entityId];
            const pct = Math.min(100, (s.recognizedAmount / s.totalAmount) * 100);
            return (
              <div key={s.id} className="rounded-lg border border-slate-200 p-3">
                <div className="flex items-center justify-between text-sm">
                  <div>
                    <span className="font-medium text-slate-800">{entity?.name ?? "Unknown entity"}</span>
                    <span className="ml-2 text-slate-400">· {feeType?.name}</span>
                  </div>
                  <Badge tone={s.status === "ACTIVE" ? "indigo" : "emerald"}>{s.status}</Badge>
                </div>
                <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full rounded-full bg-emerald-500" style={{ width: `${pct}%` }} />
                </div>
                <div className="mt-1.5 flex justify-between text-xs text-slate-500">
                  <span>Recognised {fmt(s.recognizedAmount)} of {fmt(s.totalAmount)}</span>
                  <span>Remaining {fmt(s.remainingBalance)} · ends {new Date(s.endDate).toLocaleDateString()}</span>
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Receipts Page (list + new receipt form)
// ─────────────────────────────────────────────────────────────

function ReceiptsPage({ data, derived, createReceipt, addEntity, showToast }) {
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState("");
  const activeFeeTypes = data.feeTypes.filter((f) => f.isActive);

  const filtered = data.receipts.filter((r) => {
    const entity = derived.entityById[r.entityId];
    return !search || r.receiptNumber.toLowerCase().includes(search.toLowerCase()) || entity?.name.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div>
      <SectionHeader
        title="Receipts"
        description="Every payment, however many fee types it covers, under one receipt number."
        action={<Btn onClick={() => setShowForm(true)}><Plus size={15} /> Record Payment</Btn>}
      />

      <div className="mb-3 flex items-center gap-2">
        <div className="relative w-72">
          <Search size={14} className="absolute left-3 top-2.5 text-slate-400" />
          <input className={`${inputCls} pl-8`} placeholder="Search receipt no. or entity…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      <DataTable
        keyField="id"
        emptyMessage="No receipts recorded yet. Click “Record Payment” to create the first one."
        columns={[
          { header: "Receipt No.", render: (r) => <span className="font-mono font-medium text-slate-800">{r.receiptNumber}</span> },
          { header: "Entity", render: (r) => derived.entityById[r.entityId]?.name ?? "—" },
          { header: "Fee Types", render: (r) => r.lineItems.map((li) => derived.feeTypeById[li.feeTypeId]?.name).join(", ") },
          { header: "Method", render: (r) => <Badge>{r.paymentMethod.replace("_", " ")}</Badge> },
          { header: "Total", render: (r) => <span className="font-mono">{fmt(r.totalAmount)}</span> },
          { header: "Date", render: (r) => new Date(r.paymentDate).toLocaleDateString() },
        ]}
        data={filtered}
      />

      <Modal open={showForm} onClose={() => setShowForm(false)} title="Record a Payment" wide>
        <ReceiptForm
          feeTypes={activeFeeTypes}
          entities={data.entities}
          addEntity={addEntity}
          onSubmit={(input) => {
            const receiptNumber = createReceipt(input);
            setShowForm(false);
            showToast(`Receipt ${receiptNumber} issued for ${fmt(input.lineItems.reduce((s, li) => s + Number(li.amount), 0))}.`);
          }}
        />
      </Modal>
    </div>
  );
}

function ReceiptForm({ feeTypes, entities, addEntity, onSubmit }) {
  const [entityId, setEntityId] = useState("");
  const [entityQuery, setEntityQuery] = useState("");
  const [showNewEntity, setShowNewEntity] = useState(false);
  const [newEntityName, setNewEntityName] = useState("");
  const [newEntityType, setNewEntityType] = useState("Project Developer");
  const [paymentMethod, setPaymentMethod] = useState("CASH");
  const [collectedBy, setCollectedBy] = useState("");
  const [notes, setNotes] = useState("");
  const [rows, setRows] = useState([{ rowId: uid(), feeTypeId: "", amount: "", months: "" }]);

  const matchedEntities = entities.filter((e) => e.name.toLowerCase().includes(entityQuery.toLowerCase())).slice(0, 6);
  const selectedEntity = entities.find((e) => e.id === entityId);
  const total = rows.reduce((s, r) => s + (parseFloat(r.amount) || 0), 0);

  function updateRow(rowId, patch) {
    setRows((rs) => rs.map((r) => (r.rowId === rowId ? { ...r, ...patch } : r)));
  }
  function addRow() {
    setRows((rs) => [...rs, { rowId: uid(), feeTypeId: "", amount: "", months: "" }]);
  }
  function removeRow(rowId) {
    setRows((rs) => (rs.length > 1 ? rs.filter((r) => r.rowId !== rowId) : rs));
  }

  function handleCreateEntity() {
    if (!newEntityName.trim()) return;
    const record = addEntity({ name: newEntityName.trim(), entityType: newEntityType, registrationNumber: "", email: "", phone: "", address: "" });
    setEntityId(record.id);
    setEntityQuery(record.name);
    setShowNewEntity(false);
    setNewEntityName("");
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!entityId || rows.some((r) => !r.feeTypeId || !r.amount)) return;
    onSubmit({
      entityId, paymentMethod, collectedBy, notes,
      lineItems: rows.map((r) => ({ feeTypeId: r.feeTypeId, amount: parseFloat(r.amount), months: r.months ? parseInt(r.months) : undefined })),
    });
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Field label="Entity">
        <div className="relative">
          <input
            className={inputCls}
            placeholder="Search entity by name…"
            value={selectedEntity ? selectedEntity.name : entityQuery}
            onChange={(e) => { setEntityQuery(e.target.value); setEntityId(""); }}
          />
          {entityQuery && !entityId && (
            <div className="absolute z-10 mt-1 w-full rounded-md border border-slate-200 bg-white shadow-lg">
              {matchedEntities.map((e) => (
                <button key={e.id} type="button" onClick={() => { setEntityId(e.id); setEntityQuery(e.name); }} className="block w-full px-3 py-2 text-left text-sm hover:bg-slate-50">
                  {e.name} <span className="text-xs text-slate-400">· {e.entityType}</span>
                </button>
              ))}
              <button type="button" onClick={() => setShowNewEntity(true)} className="block w-full border-t border-slate-100 px-3 py-2 text-left text-sm text-indigo-600 hover:bg-slate-50">
                + Create new entity “{entityQuery}”
              </button>
            </div>
          )}
        </div>
      </Field>

      {showNewEntity && (
        <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-2">
          <Field label="Entity name">
            <input className={inputCls} value={newEntityName || entityQuery} onChange={(e) => setNewEntityName(e.target.value)} />
          </Field>
          <Field label="Entity type">
            <select className={inputCls} value={newEntityType} onChange={(e) => setNewEntityType(e.target.value)}>
              <option>Project Developer</option><option>Verifier</option><option>Government Body</option><option>Financial Institution</option><option>Other</option>
            </select>
          </Field>
          <Btn size="sm" onClick={handleCreateEntity}>Save Entity</Btn>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3">
        <Field label="Payment method">
          <select className={inputCls} value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
            <option value="CASH">Cash</option><option value="BANK_TRANSFER">Bank Transfer</option>
            <option value="CHEQUE">Cheque</option><option value="MOBILE_MONEY">Mobile Money</option><option value="CARD">Card</option>
          </select>
        </Field>
        <Field label="Collecting officer">
          <input className={inputCls} placeholder="e.g. A. Mensah" value={collectedBy} onChange={(e) => setCollectedBy(e.target.value)} />
        </Field>
      </div>

      <div>
        <div className="mb-2 flex items-center justify-between">
          <span className="text-xs font-medium text-slate-600">Fee line items</span>
          <button type="button" onClick={addRow} className="flex items-center gap-1 text-xs font-medium text-indigo-600"><Plus size={13} /> Add fee</button>
        </div>
        <div className="space-y-2">
          {rows.map((row) => {
            const ft = feeTypes.find((f) => f.id === row.feeTypeId);
            return (
              <div key={row.rowId} className="rounded-lg border border-slate-200 p-2.5">
                <div className="grid grid-cols-12 gap-2">
                  <select className={`${inputCls} col-span-5`} value={row.feeTypeId} onChange={(e) => updateRow(row.rowId, { feeTypeId: e.target.value })}>
                    <option value="">Select fee type…</option>
                    {feeTypes.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
                  </select>
                  <input type="number" min="0.01" step="0.01" placeholder="Amount" className={`${inputCls} col-span-4`} value={row.amount} onChange={(e) => updateRow(row.rowId, { amount: e.target.value })} />
                  {ft?.category === "DEFERRED" && (
                    <input type="number" min="1" placeholder={`Months (default ${ft.defaultMonths})`} className={`${inputCls} col-span-2`} value={row.months} onChange={(e) => updateRow(row.rowId, { months: e.target.value })} />
                  )}
                  <button type="button" onClick={() => removeRow(row.rowId)} className="col-span-1 flex items-center justify-center text-red-400 hover:text-red-600"><Trash2 size={14} /></button>
                </div>
                {ft?.category === "DEFERRED" && (
                  <p className="mt-1.5 text-xs text-amber-600">Recognised as deferred income, released monthly over {row.months || ft.defaultMonths} months.</p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2.5">
        <span className="text-sm font-medium text-slate-600">Total</span>
        <span className="font-mono text-base font-semibold text-slate-900">{fmt(total)}</span>
      </div>

      <textarea placeholder="Notes (optional)" className={inputCls} rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />

      <Btn type="submit" className="w-full justify-center" disabled={!entityId}>Record Payment &amp; Issue Receipt</Btn>
    </form>
  );
}

// ─────────────────────────────────────────────────────────────
// Entities Page
// ─────────────────────────────────────────────────────────────

function EntitiesPage({ data, addEntity, derived, showToast }) {
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({ name: "", entityType: "Project Developer", registrationNumber: "", email: "", phone: "", address: "" });

  const filtered = data.entities.filter((e) => !search || e.name.toLowerCase().includes(search.toLowerCase()));

  function handleSubmit(e) {
    e.preventDefault();
    if (!form.name.trim()) return;
    addEntity(form);
    showToast(`Entity “${form.name}” created.`);
    setForm({ name: "", entityType: "Project Developer", registrationNumber: "", email: "", phone: "", address: "" });
    setShowForm(false);
  }

  return (
    <div>
      <SectionHeader title="Entities" description="Registrants participating in the national carbon registry." action={<Btn onClick={() => setShowForm(true)}><Plus size={15} /> New Entity</Btn>} />
      <div className="mb-3 relative w-72">
        <Search size={14} className="absolute left-3 top-2.5 text-slate-400" />
        <input className={`${inputCls} pl-8`} placeholder="Search entities…" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>
      <DataTable
        keyField="id"
        emptyMessage="No entities yet."
        columns={[
          { header: "Name", render: (e) => <span className="font-medium text-slate-800">{e.name}</span> },
          { header: "Type", render: (e) => e.entityType },
          { header: "Reg. No.", render: (e) => e.registrationNumber || "—" },
          { header: "Contact", render: (e) => e.email || e.phone || "—" },
          { header: "Total Paid", render: (e) => <span className="font-mono">{fmt(data.receipts.filter((r) => r.entityId === e.id).reduce((s, r) => s + r.totalAmount, 0))}</span> },
        ]}
        data={filtered}
      />
      <Modal open={showForm} onClose={() => setShowForm(false)} title="New Entity">
        <form onSubmit={handleSubmit} className="space-y-3">
          <Field label="Name"><input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></Field>
          <Field label="Entity type">
            <select className={inputCls} value={form.entityType} onChange={(e) => setForm({ ...form, entityType: e.target.value })}>
              <option>Project Developer</option><option>Verifier</option><option>Government Body</option><option>Financial Institution</option><option>Other</option>
            </select>
          </Field>
          <Field label="Registration number"><input className={inputCls} value={form.registrationNumber} onChange={(e) => setForm({ ...form, registrationNumber: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Email"><input className={inputCls} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
            <Field label="Phone"><input className={inputCls} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
          </div>
          <Field label="Address"><input className={inputCls} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></Field>
          <Btn type="submit" className="w-full justify-center">Save Entity</Btn>
        </form>
      </Modal>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Fee Types Page
// ─────────────────────────────────────────────────────────────

function FeeTypesPage({ data, addFeeType, toggleFeeType, showToast }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", code: "", category: "IMMEDIATE", defaultMonths: "" });

  function handleSubmit(e) {
    e.preventDefault();
    if (!form.name.trim() || !form.code.trim()) return;
    addFeeType({ name: form.name, code: form.code.toUpperCase(), category: form.category, defaultMonths: form.category === "DEFERRED" ? Number(form.defaultMonths) || 12 : null });
    showToast(`Fee type “${form.name}” added.`);
    setForm({ name: "", code: "", category: "IMMEDIATE", defaultMonths: "" });
    setShowForm(false);
  }

  return (
    <div>
      <SectionHeader title="Fee Types" description="Configure how each fee is recognised — instantly or spread over a service period." action={<Btn onClick={() => setShowForm(true)}><Plus size={15} /> New Fee Type</Btn>} />
      <DataTable
        keyField="id"
        columns={[
          { header: "Name", render: (f) => <span className="font-medium text-slate-800">{f.name}</span> },
          { header: "Code", render: (f) => <span className="font-mono text-xs">{f.code}</span> },
          { header: "Recognition", render: (f) => <Badge tone={f.category === "DEFERRED" ? "amber" : "emerald"}>{f.category === "DEFERRED" ? `Deferred · ${f.defaultMonths} mo` : "Immediate"}</Badge> },
          { header: "Status", render: (f) => <Badge tone={f.isActive ? "indigo" : "slate"}>{f.isActive ? "Active" : "Inactive"}</Badge> },
          { header: "", render: (f) => <button onClick={() => toggleFeeType(f.id)} className="text-xs font-medium text-indigo-600">{f.isActive ? "Deactivate" : "Activate"}</button> },
        ]}
        data={data.feeTypes}
      />
      <Modal open={showForm} onClose={() => setShowForm(false)} title="New Fee Type">
        <form onSubmit={handleSubmit} className="space-y-3">
          <Field label="Name"><input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></Field>
          <Field label="Code"><input className={inputCls} value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="e.g. AUD" required /></Field>
          <Field label="Recognition category">
            <select className={inputCls} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              <option value="IMMEDIATE">Immediate — earned on collection</option>
              <option value="DEFERRED">Deferred — recognised over a service period</option>
            </select>
          </Field>
          {form.category === "DEFERRED" && (
            <Field label="Default recognition period (months)" hint="Can be overridden per receipt line item."><input type="number" className={inputCls} value={form.defaultMonths} onChange={(e) => setForm({ ...form, defaultMonths: e.target.value })} /></Field>
          )}
          <Btn type="submit" className="w-full justify-center">Save Fee Type</Btn>
        </form>
      </Modal>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Reports Page
// ─────────────────────────────────────────────────────────────

function ReportsPage({ data, derived }) {
  const reports = [
    {
      title: "Daily Collection Report", description: "All receipts recorded today.",
      run: () => downloadCsv("daily-collection-report.csv", data.receipts.filter((r) => r.paymentDate.startsWith(new Date().toISOString().slice(0, 10))), [
        { header: "Receipt No.", value: (r) => r.receiptNumber }, { header: "Entity", value: (r) => derived.entityById[r.entityId]?.name },
        { header: "Amount", value: (r) => r.totalAmount }, { header: "Method", value: (r) => r.paymentMethod },
      ]),
    },
    {
      title: "Monthly Collection Report", description: "All receipts for the current month.",
      run: () => downloadCsv("monthly-collection-report.csv", data.receipts.filter((r) => r.paymentDate.startsWith(derived.currentMonthKey)), [
        { header: "Receipt No.", value: (r) => r.receiptNumber }, { header: "Entity", value: (r) => derived.entityById[r.entityId]?.name },
        { header: "Amount", value: (r) => r.totalAmount }, { header: "Date", value: (r) => r.paymentDate },
      ]),
    },
    {
      title: "Revenue Recognition Report", description: "Every recognition entry, immediate and deferred.",
      run: () => downloadCsv("revenue-recognition-report.csv", data.recognitions, [
        { header: "Entity", value: (r) => derived.entityById[r.entityId]?.name }, { header: "Fee Type", value: (r) => derived.feeTypeById[r.feeTypeId]?.name },
        { header: "Period", value: (r) => r.period }, { header: "Type", value: (r) => r.type }, { header: "Amount", value: (r) => r.amount },
      ]),
    },
    {
      title: "Deferred Income Report", description: "Balances remaining across all prepaid contracts.",
      run: () => downloadCsv("deferred-income-report.csv", data.schedules, [
        { header: "Entity", value: (r) => derived.entityById[r.entityId]?.name }, { header: "Fee Type", value: (r) => derived.feeTypeById[r.feeTypeId]?.name },
        { header: "Total", value: (r) => r.totalAmount }, { header: "Recognised", value: (r) => r.recognizedAmount },
        { header: "Remaining", value: (r) => r.remainingBalance }, { header: "Status", value: (r) => r.status }, { header: "Ends", value: (r) => r.endDate },
      ]),
    },
    {
      title: "Entity Payment History", description: "Full receipt history across all entities.",
      run: () => downloadCsv("entity-payment-history.csv", data.receipts, [
        { header: "Entity", value: (r) => derived.entityById[r.entityId]?.name }, { header: "Receipt No.", value: (r) => r.receiptNumber },
        { header: "Amount", value: (r) => r.totalAmount }, { header: "Date", value: (r) => r.paymentDate },
      ]),
    },
    {
      title: "Fee Type Analysis", description: "Revenue recognised, grouped by fee type.",
      run: () => downloadCsv("fee-type-analysis.csv", derived.revenueByFeeType, [{ header: "Fee Type", value: (r) => r.name }, { header: "Revenue", value: (r) => r.value }]),
    },
    {
      title: "Bank / Method Collection Report", description: "Collections grouped by payment method.",
      run: () => downloadCsv("bank-collection-report.csv", derived.collectionsByMethod, [{ header: "Method", value: (r) => r.name }, { header: "Amount", value: (r) => r.value }]),
    },
    {
      title: "Audit Trail Report", description: "Full log of system actions.",
      run: () => downloadCsv("audit-trail-report.csv", data.auditLog, [
        { header: "User", value: (r) => r.user }, { header: "Action", value: (r) => r.action }, { header: "Entity", value: (r) => r.entityName },
        { header: "Record", value: (r) => r.recordId }, { header: "Timestamp", value: (r) => r.timestamp },
      ]),
    },
    {
      title: "Journal Entry Report", description: "All generated accounting journal entries, ready for import.",
      run: () => downloadCsv("journal-entry-report.csv", data.journalEntries, [
        { header: "Date", value: (r) => r.date }, { header: "Period", value: (r) => r.period }, { header: "Debit", value: (r) => r.debitAccount },
        { header: "Credit", value: (r) => r.creditAccount }, { header: "Amount", value: (r) => r.amount }, { header: "Description", value: (r) => r.description },
      ]),
    },
  ];

  return (
    <div>
      <SectionHeader title="Reports" description="Export any report to CSV for Excel or your accounting system." />
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
        {reports.map((r) => (
          <Card key={r.title} className="flex items-center justify-between p-4">
            <div>
              <p className="text-sm font-medium text-slate-800">{r.title}</p>
              <p className="text-xs text-slate-500">{r.description}</p>
            </div>
            <Btn variant="secondary" size="sm" onClick={r.run}><Download size={13} /> Export</Btn>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Audit Trail Page
// ─────────────────────────────────────────────────────────────

function AuditPage({ data }) {
  return (
    <div>
      <SectionHeader title="Audit Trail" description="Every create, update, and recognition-run action recorded by the system." />
      <DataTable
        keyField="id"
        emptyMessage="No activity logged yet."
        columns={[
          { header: "Timestamp", render: (a) => new Date(a.timestamp).toLocaleString() },
          { header: "User", render: (a) => a.user },
          { header: "Action", render: (a) => <Badge tone="indigo">{a.action}</Badge> },
          { header: "Entity", render: (a) => a.entityName },
          { header: "Record", render: (a) => <span className="font-mono text-xs">{a.recordId}</span> },
          { header: "Detail", render: (a) => a.extra || "—" },
        ]}
        data={data.auditLog}
      />
    </div>
  );
}
