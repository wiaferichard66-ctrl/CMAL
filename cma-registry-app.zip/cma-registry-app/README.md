# CMA Registry Revenue Management System

A fee collection, deferred income, and revenue recognition dashboard for a
national carbon registry — built with React, Vite, Tailwind CSS, and Recharts.

## What this is

This is a working front-end implementation of the system: entity management,
multi-fee-type receipts, automatic deferred-income scheduling, monthly
revenue recognition, journal entry generation, three role-aware dashboards
(Executive, Registry, Collection), and nine exportable CSV reports.

Data currently persists in the browser's `localStorage` — there is no backend
or database yet. Everything works as a self-contained single-user app. See
"Moving to a real backend" below for how to connect it to Postgres.

## Run it locally

Requires Node.js 18+.

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview
```

`npm run build` outputs static files to `dist/` — deployable to any static
host (Vercel, Netlify, GitHub Pages, S3, etc.).

## Project structure

```
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
└── src/
    ├── main.jsx      ← React entry point
    ├── index.css     ← Tailwind directives
    └── App.jsx       ← the entire application
```

`App.jsx` is currently a single file for simplicity. As the app grows, the
natural next step is splitting it into `src/features/{entities,receipts,
feeTypes,revenue,dashboards,reports}` — see the architecture notes below.

## Pushing to GitHub

```bash
git init
git add .
git commit -m "Initial commit: CMA Registry Revenue Management System"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

## Moving to a real backend

This front end was designed against a full Node.js/Express/PostgreSQL/Prisma
backend (fee collection, deferred income schedules, monthly recognition job,
journal entry generation, role-based access, audit trail). To connect it:

1. Stand up the backend (Prisma schema, Express routes, JWT auth).
2. Replace the `localStorage` calls in `App.jsx` (`window.localStorage.getItem`
   / `setItem` inside the two `useEffect` hooks near the top of the `CMARegistryApp`
   component) with `fetch` calls to your API.
3. Split state mutations (`createReceipt`, `runMonthlyRecognition`, etc.) into
   API calls instead of local `setData` updates.

The data shapes already used in this app (`entities`, `feeTypes`, `receipts`,
`schedules`, `recognitions`, `journalEntries`, `auditLog`) map directly onto
Prisma models of the same names, so this swap is mechanical rather than a
redesign.

## Tech stack

- React 18 + Vite
- Tailwind CSS
- Recharts (dashboards)
- lucide-react (icons)
